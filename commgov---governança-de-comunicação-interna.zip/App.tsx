
import React, { useState, useEffect } from 'react';
import { CommunicationEntry } from './types.ts';
import { MOCK_DATA } from './constants.ts';
import Dashboard from './components/Dashboard.tsx';
import RegistrationForm from './components/RegistrationForm.tsx';
import QueryTable from './components/QueryTable.tsx';
import AnalysisView from './components/AnalysisView.tsx';
import CalendarView from './components/CalendarView.tsx';

type Tab = 'dashboard' | 'calendar' | 'register' | 'query' | 'analysis';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [entries, setEntries] = useState<CommunicationEntry[]>(() => {
    const saved = localStorage.getItem('commgov_entries');
    return saved ? JSON.parse(saved) : MOCK_DATA;
  });
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [editingEntry, setEditingEntry] = useState<CommunicationEntry | null>(null);

  useEffect(() => {
    localStorage.setItem('commgov_entries', JSON.stringify(entries));
  }, [entries]);

  const addEntry = (entry: CommunicationEntry) => {
    setEntries([entry, ...entries]);
    setActiveTab('query');
  };

  const updateEntry = (updatedEntry: CommunicationEntry) => {
    setEntries(entries.map(e => e.id === updatedEntry.id ? updatedEntry : e));
    setEditingEntry(null);
    setActiveTab('query');
  };

  const deleteEntry = (id: string) => {
    if (confirm('Deseja excluir este registro permanentemente?')) {
      setEntries(entries.filter(e => e.id !== id));
    }
  };

  const handleEdit = (entry: CommunicationEntry) => {
    setEditingEntry(entry);
    setActiveTab('register');
  };

  const handleAddFromCalendar = (date: string) => {
    setSelectedDate(date);
    setEditingEntry(null);
    setActiveTab('register');
  };

  const menuItems = [
    { id: 'dashboard', label: 'Início', icon: <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v4a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v4a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v4a2 2 0 01-2 2H6a2 2 0 01-2-2v-4zM14 16a2 2 0 012-2h2a2 2 0 012 2v4a2 2 0 01-2 2h-2a2 2 0 01-2-2v-4z"/></svg> },
    { id: 'calendar', label: 'Cronograma', icon: <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg> },
    { id: 'register', label: 'Novo Registro', icon: <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4"/></svg> },
    { id: 'query', label: 'Consultar', icon: <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg> },
    { id: 'analysis', label: 'IA Insights', icon: <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/></svg> },
  ];

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Sidebar */}
      <aside className="hidden md:flex flex-col w-64 bg-slate-900 text-white shrink-0">
        <div className="p-6">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-indigo-500 rounded-lg flex items-center justify-center font-bold text-white shadow-lg">C</div>
            <h1 className="text-xl font-extrabold tracking-tight">CommGov</h1>
          </div>
          <p className="text-[10px] text-slate-400 mt-1 uppercase tracking-widest font-bold">Comunicação AP3</p>
        </div>
        
        <nav className="flex-1 px-4 space-y-1">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setActiveTab(item.id as Tab);
                if (item.id !== 'register') {
                  setEditingEntry(null);
                  setSelectedDate(null);
                }
              }}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all duration-200 ${
                activeTab === item.id 
                ? 'bg-indigo-600 text-white shadow-indigo-500/20 shadow-lg' 
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              {item.icon}
              {item.label}
            </button>
          ))}
        </nav>

        <div className="p-4 mt-auto">
          <div className="bg-slate-800/50 rounded-2xl p-4 border border-slate-700/50">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center">
                <span className="text-indigo-400 font-bold">AM</span>
              </div>
              <div>
                <p className="text-xs font-bold">Álamo Monteiro</p>
                <p className="text-[10px] text-slate-500">Gestor de Gente</p>
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto bg-slate-50 relative">
        <header className="sticky top-0 z-20 glass border-b border-slate-200/60 px-8 py-4 flex items-center justify-between">
          <h2 className="text-lg font-bold text-slate-800">
            {menuItems.find(m => m.id === activeTab)?.label}
          </h2>
          <div className="flex items-center gap-4">
            <span className="text-xs font-bold text-slate-400 bg-slate-100 px-3 py-1 rounded-full">
              {entries.length} Registros Totais
            </span>
            <button className="text-slate-500 hover:text-indigo-600 transition-colors">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/></svg>
            </button>
          </div>
        </header>

        <div className="p-8 max-w-7xl mx-auto">
          {activeTab === 'dashboard' && <Dashboard data={entries} />}
          {activeTab === 'calendar' && <CalendarView data={entries} onAddFromCalendar={handleAddFromCalendar} onEditEvent={handleEdit} />}
          {activeTab === 'register' && <RegistrationForm onAdd={addEntry} onUpdate={updateEntry} initialDate={selectedDate || undefined} editingEntry={editingEntry || undefined} />}
          {activeTab === 'query' && <QueryTable data={entries} onEdit={handleEdit} onDelete={deleteEntry} />}
          {activeTab === 'analysis' && <AnalysisView data={entries} />}
        </div>

        {/* Mobile Navigation */}
        <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 px-4 py-2 flex justify-around z-50">
          {menuItems.map(item => (
            <button 
              key={item.id} 
              onClick={() => setActiveTab(item.id as Tab)}
              className={`p-2 rounded-lg ${activeTab === item.id ? 'text-indigo-600' : 'text-slate-400'}`}
            >
              {item.icon}
            </button>
          ))}
        </nav>
      </main>
    </div>
  );
};

export default App;
