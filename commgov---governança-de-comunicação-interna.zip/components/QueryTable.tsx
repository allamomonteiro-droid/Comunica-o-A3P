
import React, { useState, useMemo } from 'react';
import { CommunicationEntry } from '../types.ts';
import { CHANNELS, STATUSES } from '../constants.ts';

interface QueryTableProps {
  data: CommunicationEntry[];
  onEdit: (entry: CommunicationEntry) => void;
  onDelete: (id: string) => void;
}

const QueryTable: React.FC<QueryTableProps> = ({ data, onEdit, onDelete }) => {
  const [search, setSearch] = useState('');
  const [filterChannel, setFilterChannel] = useState('');

  const filtered = useMemo(() => {
    return data.filter(item => 
      item.title.toLowerCase().includes(search.toLowerCase()) &&
      (filterChannel === '' || item.channel === filterChannel)
    );
  }, [data, search, filterChannel]);

  return (
    <div className="bg-white rounded-[32px] border border-slate-200/60 shadow-sm overflow-hidden">
      <div className="p-6 border-b border-slate-100 flex flex-wrap items-center justify-between gap-4 bg-slate-50/30">
        <div className="flex items-center gap-3 bg-white px-4 py-2 rounded-2xl border border-slate-200/80 w-full md:w-96 focus-within:ring-2 focus-within:ring-indigo-500 transition-all">
          <svg className="w-5 h-5 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
          <input 
            type="text" 
            placeholder="Pesquisar por título ou responsável..." 
            className="bg-transparent border-none outline-none text-sm w-full font-medium"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <select 
          className="bg-white px-4 py-2 rounded-2xl border border-slate-200/80 text-sm font-bold text-slate-600 outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
          value={filterChannel}
          onChange={(e) => setFilterChannel(e.target.value)}
        >
          <option value="">Todos os Canais</option>
          {CHANNELS.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-slate-50/50">
              <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Data</th>
              <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Iniciativa</th>
              <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Canal</th>
              <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Público</th>
              <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Status</th>
              <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-right">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filtered.map(item => (
              <tr key={item.id} className="hover:bg-slate-50/80 transition-colors group">
                <td className="px-6 py-4">
                  <span className="text-xs font-bold text-slate-500">{new Date(item.date).toLocaleDateString('pt-BR')}</span>
                </td>
                <td className="px-6 py-4">
                  <p className="text-sm font-bold text-slate-800">{item.title}</p>
                  <p className="text-[10px] text-slate-400 font-medium">{item.responsible}</p>
                </td>
                <td className="px-6 py-4">
                  <span className="text-[10px] font-extrabold px-2 py-1 rounded-lg bg-indigo-50 text-indigo-600 uppercase">
                    {item.channel}
                  </span>
                </td>
                <td className="px-6 py-4">
                   <span className="text-[10px] font-bold text-slate-600">{item.audience}</span>
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-1.5">
                    <div className={`w-1.5 h-1.5 rounded-full ${item.status === 'Executada' ? 'bg-emerald-500' : 'bg-amber-500'}`}></div>
                    <span className="text-xs font-bold text-slate-700">{item.status}</span>
                  </div>
                </td>
                <td className="px-6 py-4 text-right">
                  <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={() => onEdit(item)} className="p-2 hover:bg-white rounded-xl text-slate-400 hover:text-indigo-600 shadow-sm border border-transparent hover:border-slate-200 transition-all">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"/></svg>
                    </button>
                    <button onClick={() => onDelete(item.id)} className="p-2 hover:bg-white rounded-xl text-slate-400 hover:text-rose-600 shadow-sm border border-transparent hover:border-slate-200 transition-all">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && (
          <div className="p-20 text-center">
            <p className="text-slate-400 font-bold">Nenhum registro encontrado.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default QueryTable;