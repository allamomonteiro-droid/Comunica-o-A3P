
import React, { useState, useEffect } from 'react';
import { CommunicationEntry } from '../types.ts';
import { getStrategicInsights } from '../services/geminiService.ts';

interface AnalysisViewProps {
  data: CommunicationEntry[];
}

const AnalysisView: React.FC<AnalysisViewProps> = ({ data }) => {
  const [insights, setInsights] = useState<{ insights: string[], suggestions: string[] } | null>(null);
  const [loading, setLoading] = useState(false);

  const fetchInsights = async () => {
    setLoading(true);
    try {
      const result = await getStrategicInsights(data);
      setInsights(result);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (data.length > 0 && !insights) fetchInsights();
  }, [data]);

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in slide-in-from-bottom-4 duration-500">
      <div className="bg-slate-900 rounded-[32px] p-10 text-white relative overflow-hidden shadow-2xl">
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-indigo-500 rounded-2xl flex items-center justify-center">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
            </div>
            <h2 className="text-3xl font-extrabold">People AI Advisor</h2>
          </div>
          <p className="text-slate-400 text-lg max-w-xl leading-relaxed">
            Nossa inteligência analisa seus {data.length} registros para identificar gargalos e oportunidades na jornada do colaborador.
          </p>
          <button 
            onClick={fetchInsights}
            disabled={loading}
            className="mt-8 bg-indigo-600 hover:bg-indigo-500 px-8 py-3 rounded-2xl font-bold transition-all flex items-center gap-3 disabled:opacity-50"
          >
            {loading ? 'Analisando Base de Dados...' : 'Gerar Novo Relatório'}
          </button>
        </div>
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-600/10 blur-[100px] rounded-full"></div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-4">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-2">Diagnóstico de Canais</h3>
          {loading ? (
            <div className="space-y-4">
              {[1,2,3].map(i => <div key={i} className="h-24 bg-white rounded-3xl animate-pulse"></div>)}
            </div>
          ) : (
            insights?.insights.map((text, i) => (
              <div key={i} className="bg-white p-6 rounded-3xl border border-slate-200/60 shadow-sm flex gap-4 items-start">
                <div className="w-8 h-8 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold text-xs shrink-0">0{i+1}</div>
                <p className="text-sm text-slate-600 leading-relaxed font-medium">{text}</p>
              </div>
            ))
          )}
        </div>

        <div className="space-y-4">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-2">Ações Sugeridas</h3>
          {loading ? (
            <div className="space-y-4">
              {[1,2,3].map(i => <div key={i} className="h-24 bg-white rounded-3xl animate-pulse"></div>)}
            </div>
          ) : (
            insights?.suggestions.map((text, i) => (
              <div key={i} className="bg-indigo-50/30 p-6 rounded-3xl border border-indigo-100 shadow-sm flex gap-4 items-start">
                <div className="w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center font-bold text-xs shrink-0">
                   <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"/></svg>
                </div>
                <p className="text-sm text-indigo-900 leading-relaxed font-semibold">{text}</p>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default AnalysisView;