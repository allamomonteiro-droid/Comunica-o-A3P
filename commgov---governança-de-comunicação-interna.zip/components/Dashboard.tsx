
import React, { useMemo } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  AreaChart, Area, Cell, PieChart, Pie
} from 'recharts';
import { CommunicationEntry } from '../types.ts';

interface DashboardProps {
  data: CommunicationEntry[];
}

const COLORS = ['#6366f1', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

const Dashboard: React.FC<DashboardProps> = ({ data }) => {
  const stats = useMemo(() => {
    const channelMap: Record<string, number> = {};
    const effectivenessMap: Record<string, number> = { 'Sim': 0, 'Parcialmente': 0, 'Não': 0 };
    let spent = 0;
    let budgeted = 0;

    data.forEach(item => {
      channelMap[item.channel] = (channelMap[item.channel] || 0) + 1;
      effectivenessMap[item.isComprehended]++;
      spent += Number(item.spentValue || 0);
      budgeted += Number(item.budgetedValue || 0);
    });

    const reachRate = data.length > 0 
      ? Math.round((effectivenessMap['Sim'] + (effectivenessMap['Parcialmente'] * 0.5)) / data.length * 100) 
      : 0;

    return {
      channelData: Object.entries(channelMap).map(([name, value]) => ({ name, value })),
      pieData: Object.entries(effectivenessMap).map(([name, value]) => ({ name, value })),
      spent,
      budgeted,
      reachRate
    };
  }, [data]);

  const StatCard = ({ title, value, sub, icon, trend }: any) => (
    <div className="bg-white p-6 rounded-3xl border border-slate-200/60 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">{title}</p>
          <h4 className="text-2xl font-extrabold text-slate-900 mt-1">{value}</h4>
          <p className="text-[10px] text-slate-500 mt-1 font-medium">{sub}</p>
        </div>
        <div className="p-3 bg-slate-50 rounded-2xl text-slate-600">
          {icon}
        </div>
      </div>
      {trend && (
        <div className="mt-4 flex items-center gap-1">
          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${trend > 0 ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-600'}`}>
            {trend > 0 ? `+${trend}%` : `${trend}%`}
          </span>
          <span className="text-[10px] text-slate-400">vs. mês anterior</span>
        </div>
      )}
    </div>
  );

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      {/* KPI Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          title="Saúde da Comunicação" 
          value={`${stats.reachRate}%`} 
          sub="Efetividade global de compreensão"
          icon={<svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>}
          trend={12}
        />
        <StatCard 
          title="Investimento Total" 
          value={new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(stats.spent)} 
          sub={`Budget total: ${new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(stats.budgeted)}`}
          icon={<svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>}
        />
        <StatCard 
          title="Ações Realizadas" 
          value={data.length} 
          sub="Total de comunicações registradas"
          icon={<svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg>}
          trend={-5}
        />
        <StatCard 
          title="Principais Canais" 
          value={stats.channelData.length} 
          sub="Mix de canais utilizados"
          icon={<svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-8 rounded-[32px] border border-slate-200/60 shadow-sm h-[450px]">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h3 className="text-lg font-bold text-slate-800">Distribuição por Canal</h3>
              <p className="text-xs text-slate-400 font-medium">Volume de ações enviadas em cada meio</p>
            </div>
          </div>
          <ResponsiveContainer width="100%" height="80%">
            <BarChart data={stats.channelData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis 
                dataKey="name" 
                axisLine={false} 
                tickLine={false} 
                fontSize={10} 
                fontWeight={600}
                tick={{fill: '#94a3b8'}}
              />
              <YAxis 
                axisLine={false} 
                tickLine={false} 
                fontSize={10}
                fontWeight={600}
                tick={{fill: '#94a3b8'}}
              />
              <Tooltip 
                cursor={{fill: '#f8fafc'}}
                contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)' }}
              />
              <Bar dataKey="value" fill="#6366f1" radius={[8, 8, 0, 0]} barSize={40} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white p-8 rounded-[32px] border border-slate-200/60 shadow-sm h-[450px]">
          <h3 className="text-lg font-bold text-slate-800 mb-2">Compreensão</h3>
          <p className="text-xs text-slate-400 font-medium mb-8">Feedback de entendimento do público</p>
          <ResponsiveContainer width="100%" height="70%">
            <PieChart>
              <Pie
                data={stats.pieData}
                innerRadius={60}
                outerRadius={90}
                paddingAngle={8}
                dataKey="value"
                stroke="none"
              >
                {stats.pieData.map((_, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div className="grid grid-cols-3 gap-2 mt-4">
            {stats.pieData.map((d, i) => (
              <div key={d.name} className="text-center">
                <div className="w-2 h-2 rounded-full mx-auto mb-1" style={{backgroundColor: COLORS[i]}}></div>
                <p className="text-[10px] font-bold text-slate-500">{d.name}</p>
                <p className="text-xs font-extrabold">{d.value}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;