
import { GoogleGenAI, Type } from "@google/genai";
import { CommunicationEntry } from "../types.ts";

export async function getStrategicInsights(data: CommunicationEntry[]) {
  // Safe access to API Key
  const apiKey = (typeof process !== 'undefined' && process.env) ? process.env.API_KEY : '';
  if (!apiKey) {
    console.warn("API Key not found. Returning mock insights.");
    return {
      insights: ["Configure sua chave de API para obter insights reais.", "Destaque para o uso de canais digitais.", "Monitorar o retorno de feedbacks."],
      suggestions: ["Padronizar os KPIs de retorno.", "Diversificar os canais para o público operacional.", "Realizar auditorias periódicas."]
    };
  }

  const ai = new GoogleGenAI({ apiKey });
  
  const prompt = `Analise os seguintes dados de governança de comunicação interna e forneça 3 insights estratégicos e 3 sugestões de melhoria para o RH. 
  Considere canais, objetivos e efetividade.
  
  Dados: ${JSON.stringify(data.map(d => ({ 
    canal: d.channel, 
    objetivo: d.objective, 
    tipo: d.type, 
    compreensao: d.isComprehended,
    retorno: d.returnIndicator
  })))}
  
  Responda em JSON.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.0-flash-exp", // Using a stable available model
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            insights: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            suggestions: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          },
          required: ["insights", "suggestions"]
        }
      }
    });

    const result = JSON.parse(response.text || '{}');
    return result;
  } catch (error) {
    console.error("Gemini Insight Error:", error);
    return {
      insights: ["Dados insuficientes para análise profunda.", "Destaque para o uso de canais digitais.", "Monitorar o retorno de feedbacks."],
      suggestions: ["Padronizar os KPIs de retorno.", "Diversificar os canais para o público operacional.", "Realizar auditorias periódicas."]
    };
  }
}